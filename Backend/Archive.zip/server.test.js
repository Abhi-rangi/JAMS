const request = require("supertest");
const mysql = require("mysql2");
const jestMock = require("jest-mock");
const app = require("./server"); // Corrected to use 'server.js'

jest.mock("mysql2", () => {
  const mConnection = {
    connect: jest.fn().mockImplementation((cb) => cb(null)),
    query: jest.fn(),
    end: jest.fn(),
  };
  return {
    createConnection: jest.fn(() => mConnection),
  };
});

describe("Database Connection", () => {
  test("it should connect to the database without error", () => {
    expect(mysql.createConnection().connect).toHaveBeenCalled();
  });
});

describe("API endpoints", () => {
  const db = mysql.createConnection();

  beforeEach(() => {
    db.query.mockClear();
  });

  test('GET / should respond with "Hello World!"', async () => {
    const response = await request(app).get("/");
    expect(response.text).toBe("Hello World!");
    expect(response.statusCode).toBe(200);
  });

  test("GET /vehicle-types should fetch vehicle types", async () => {
    db.query.mockImplementationOnce((sql, callback) =>
      callback(null, [{ vtype: "SUV" }, { vtype: "Sedan" }])
    );
    const response = await request(app).get("/vehicle-types");
    expect(response.statusCode).toBe(200);
    expect(response.body).toEqual([{ vtype: "SUV" }, { vtype: "Sedan" }]);
  });

  test("GET /vehicles should fetch vehicles without reservation overlap", async () => {
    db.query.mockImplementationOnce((sql, callback) => callback(null, []));
    const response = await request(app).get("/vehicles");
    expect(response.statusCode).toBe(200);
  });

  test("GET /reservations should fetch reservation details", async () => {
    db.query.mockImplementationOnce((sql, params, callback) =>
      callback(null, [])
    );
    const response = await request(app).get("/reservations");
    expect(response.statusCode).toBe(200);
  });

  test("POST /reservations should create a reservation", async () => {
    db.query.mockImplementationOnce((sql, params, callback) =>
      callback(null, { affectedRows: 1 })
    );
    const response = await request(app).post("/reservations").send({
      customerName: "John Doe",
      customerId: "12345",
      vtype: "SUV",
      vin: "VIN12345",
      startDate: "2022-01-01",
      endDate: "2022-01-05",
    });
    expect(response.statusCode).toBe(201);
    expect(response.text).toBe("Reservation created successfully");
  });
});

// Include any other test cases or additional logic here
