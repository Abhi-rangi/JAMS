module.exports = {
  setupFilesAfterEnv: ["./jest.setup.js"],
  testPathIgnorePatterns: [".next/", "./node_modules/"],
  moduleNameMapper: {
    // Handle module aliases (if you have them in your Next.js project)
  },
  testEnvironment: "jsdom",
};
