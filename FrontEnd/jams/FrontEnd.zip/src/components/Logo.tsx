import React from "react";

const Logo = () => {
  return <div className="logo">JAMS</div>;
};

export default Logo;
