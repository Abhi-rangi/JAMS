import React from "react";
import { render, screen } from "@testing-library/react";
import Logo from "../Logo"; // Adjust the path as necessary
import { describe, it } from "node:test";

describe("Logo Component", () => {
  it("renders the logo with correct text", () => {
    render(<Logo />);
    const logoElement = screen.getByText("JAMS");
    expect(logoElement).toBeInTheDocument();
    expect(logoElement).toHaveClass("logo");
  });
});
